# System 2 — Retail Support Context Strategy Evidence

## Test Result

- Test suite: `pytest tests/ -v`
- Result: **28 passed, 2 skipped**

## Successful Run

- Run ID: `20260924-105301`
- Command: `python -m retail_context.run --all`
- Baseline transcript: **38,708 tokens**
- Assembled context: **16,859 tokens**
- Reduction: **56.45%**
- Evaluation: **6/6 passed**

The submitted `budget.json`, `eval.jsonl`, and `eval_control.jsonl` contain the runtime evidence from this successful run.

## Context Breakdown

- Case facts: **204 tokens**
- Resolved refund: **381 tokens**
- Resolved subscription: **503 tokens**
- Active segment: **15,789 tokens**

Resolved refund was compressed from **12,334 → 368 tokens** and resolved subscription from **11,475 → 490 tokens**, while the active segment was preserved.

## Control Evaluation

The control evaluation produced an unexpected pass for Q1 and an expected fail for Q6. Q6 demonstrates the loss of the structured status token when the persistent facts block is removed.

## Verification

The successful runtime artifacts are preserved in `budget.json`, `eval.jsonl`, and `eval_control.jsonl`.