# System 1 — Claims Intake Agent Evidence

## Test Result

- Test suite: `pytest tests/ -v`
- Result: **29 passed**

## Successful Live Run

- Run ID: `20260925_112048`
- Command: `python -m claims_intake.run --all`
- Fixtures processed: **8**
- Estimated total cost: **$0.1411 USD**
- Outcomes: **5 routed, 3 escalated**
- Clarifications asked: **1 total**

The submitted `summary.md` contains the complete per-claim results from this successful run.

## Stop-Reason Loop Evidence

The submitted `trace.jsonl` is non-empty and shows a real run with:

- Turn 1: `stop_reason="tool_use"` with `lookup_policy` and `record_claim_fact` tool calls.
- Turn 2: `stop_reason="end_turn"` with no tool calls.

This demonstrates the loop continuing after tool use and terminating on `end_turn`.

## Verification

The successful run is preserved in `summary.md`, and the non-empty trace is preserved in `trace.jsonl`.
