# Run summary — 20260925_112048

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1411** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | escalated |  | - | 2 | 0 | 6373 | 454 | 0.0086 | 5.4 |
| claim_02_stolen_bike | routed | theft | low | 4 | 0 | 14003 | 804 | 0.018 | 9.0 |
| claim_03_water_damage | routed | property_damage | high | 7 | 1 | 26316 | 1254 | 0.0326 | 16.6 |
| claim_04_neighbor_injury | routed | liability | high | 5 | 0 | 17775 | 972 | 0.0226 | 13.5 |
| claim_05_auto_collision | routed | auto | high | 4 | 0 | 14954 | 958 | 0.0197 | 10.4 |
| claim_06_low_confidence_escalation | escalated |  | - | 3 | 0 | 9666 | 696 | 0.0131 | 8.6 |
| claim_07_tree_falls_on_car | escalated |  | - | 2 | 0 | 6276 | 506 | 0.0088 | 6.6 |
| claim_08_minor_porch_damage | routed | property_damage | low | 4 | 0 | 13963 | 711 | 0.0175 | 8.9 |
