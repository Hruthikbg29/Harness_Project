# System 4 — Recovery, Fork Isolation, and SQL Evidence

## Crash Recovery

The System 4 test suite includes crash-recovery scenarios covering:

- Resume after early interruption.
- Resume at later checkpoints.
- Fresh start after the recovery threshold.
- Fresh start when the previous run crashed.
- Fresh start when the manifest is empty.

All recovery tests passed as part of the full test suite.

## Fork / Scratchpad Isolation

The fork tests verify that:

- Forked state is copied without mutating the base state.
- Independent hypotheses use independent scratchpads.
- Findings from one fork do not appear in another fork.
- Fork findings can be merged back into the main state.

All fork/scratchpad isolation tests passed as part of the full test suite.

## SQL-Side Filtering

The warm database uses SQL-side filtering for defects:

```sql
SELECT * FROM defects
WHERE ts > ?
ORDER BY ts DESC
LIMIT ?