# Capstone Evidence

This folder follows the capstone evidence-tree naming from the project instructions.

- `system1_agentic_loop/` — System 1 pytest output, real run summary, and non-empty stop_reason trace.
- `system2_context_strategy/` — System 2 pytest output and budget/evaluation artifacts.
- `system3_claude_config/` — System 3 pytest output, validator result, and Claude Code configuration files.
- `system4_orchestration/` — System 4 pytest output, SQL-filtered shift run, hot-state size, and scratchpad evidence.
