# Reflection Brief — Harness Engineering Capstone

**Name:** Swanand Gholap

**Date:** 2026-09-24

**Environment**

- Model(s): Claude via the configured Anthropic/Vocareum environment; System 4 also used a recorded response for offline verification.

- OS / Python: Linux workspace / Python 3.13.0.

- Approx. API spend: The successful System 1 live run had an estimated cost of **$0.1411 USD**. Earlier live attempts were rejected before producing a successful response.

---

## Part 1 — Per-system

### System 1 — Agentic loop

1. **Loop control.**  

→ The loop tests verify the stop_reason sequence `["tool_use", "end_turn"]` in `tests/test_loop.py`. The continue-vs-stop decision is implemented in `claims_intake/loop.py`, function `run()`: `end_turn` returns, `tool_use` executes tools and continues, and an unexpected stop_reason raises an error. The System 1 test suite completed with 29 passed tests.

2. **Anti-pattern.**  

→ `tests/test_antipatterns.py` checks that there is no integer-literal iteration cap in the loop through `test_no_integer_literal_iteration_cap_in_loop()`. A fixed iteration cap would incorrectly terminate a valid multi-turn tool-use conversation before the model returned `end_turn`. The test suite completed with 29 passed tests, including this anti-pattern check.

3. **Tool design.**  

→ Two tools that can receive related claim information are `lookup_policy` and `record_claim_fact`. Their tool descriptions specify their different purposes: policy lookup retrieves policy information, while recording a fact updates structured claim state. The tool implementation also uses structured error information such as `is_error`, `error_category`, `is_retryable`, and `message`, allowing the agent to distinguish a retryable tool failure from a normal result instead of interpreting an arbitrary error string.

4. **Your numbers.**  

→ The successful System 1 run was `20260925_112048`. It processed all 8 claim fixtures with 5 routed outcomes and 3 escalated outcomes, asked 1 clarification in total, and recorded an estimated total cost of **$0.1411 USD**. The submitted `summary.md` contains the per-claim turn counts and token counts. The submitted `trace.jsonl` is a real non-empty trace showing `tool_use` on turn 1 and `end_turn` on turn 2. All 8 claims reached terminal outcomes; there are no incomplete outcomes in the submitted successful run.

### System 2 — Context strategy

5. **The reduction.**  

→ The baseline transcript was 38,708 tokens and the assembled context was 16,859 tokens, a 56.45% reduction. The assembled context consisted of case facts (204 tokens), resolved refund (381), resolved subscription (503), and the active segment (15,789). The active segment was the dominant section by token count.

6. **Summarize vs preserve.**  

→ The run compressed the resolved refund and subscription segments while preserving the active segment. The resolved/refund segment went from 12,334 input tokens to 368 output tokens, and resolved/subscription went from 11,475 input tokens to 490 output tokens. The resulting assembled context was 16,859 tokens versus the 38,708-token baseline.

7. **Facts block.**  

→ The System 2 evaluation passed all 6 questions (6/6). The control evaluation produced an unexpected pass for Q1 and an expected fail for Q6. The Q1 unexpected pass shows that removing the case-facts block did not prevent that particular answer, while Q6 behaved as expected because its structured status token was no longer available.

### System 3 — Claude Code config

8. **Path-scoped rules.**  

→ The frontmatter in `.claude/rules/react.md` contains `paths: - "src/components/**/*" - "src/pages/**/*"`. This scopes the React conventions to the files where they apply instead of loading them for unrelated parts of the monorepo. The rule file is therefore more targeted than putting all React conventions into a directory-level `CLAUDE.md`.

9. **Forked skill.**  

→ `.claude/skills/deploy-check/SKILL.md` contains `context: fork` and an `allowed-tools` list containing read-only tools such as `Read`, `Grep`, `Glob`, and restricted Git commands. Forking keeps verbose discovery output out of the main session, while the allowlist prevents the deploy-check skill from modifying files, pushing, or deploying. Without these controls, the check could pollute the main context and have a larger operational blast radius.

10. **Scope.**  

→ The validator command `python -m ecommerce_team_config .` returned `OK`. The project-level example is `.claude/skills/deploy-check/SKILL.md`, which is stored inside the repository and shared with the team. The skill itself documents that a stricter personal variant could live under `~/.claude/skills/`, illustrating user-level scope.

### System 4 — Orchestration

11. **Push work down.**  

→ The fixture contains 40 defects, while the pipeline asks the warm tier for only new defects through `gather_new_defects()`. The indexed query is `SELECT * FROM defects WHERE ts > ? ORDER BY ts DESC LIMIT ?`, implemented by `WarmStore.defects_since()` in `shift_monitor/warm.py`. The tests explicitly verify that the pipeline delegates to SQL and does not perform Python-side filtering, so the model receives the bounded result rather than the full defect history.

12. **Crash recovery.**  

→ `shift_monitor/recovery.py` uses a 30-minute threshold: completed work is fresh, an incomplete manifest within 30 minutes can resume, and an incomplete manifest older than 30 minutes is treated as stale and starts fresh. `tests/test_us03_crash_recovery.py` verifies 29 and 30 minutes as `resume` and 31 minutes as `fresh`, as well as empty manifests being fresh. A fresh start with an injected summary can be more reliable than replaying stale partial state because it avoids carrying forward potentially inconsistent intermediate work.

13. **Small state.**  

→ My `data/hot_state.json` is 643 bytes, verified with `wc -c`. Keeping hot state small matters because this system runs once per shift indefinitely; a bounded state keeps each shift's prompt/context manageable and prevents historical state from growing without limit.

---

### Fork isolation

→ `fork_for_hypothesis` creates a separate `data/forks/<hypothesis_id>/` directory and copies the base `hot_state.json` into that directory. The base hot state is left unchanged, so hypothesis exploration works on an isolated copy. Each fork also has its own scratchpad, which keeps findings from separate hypotheses independent. When the investigation is ready to be incorporated, `merge_findings` reads the fork scratchpads and appends their entries to the main scratchpad rather than rewriting the existing main findings. This keeps exploratory work isolated while still providing a controlled merge path back to the main state. The implementation and tests verify that the base state is not mutated and that separate fork scratchpads remain independent.

## Part 2 — Synthesis

14. **Three layers.**  

→ Model: System 1's `claims_intake/loop.py` delegates reasoning and tool selection to the Claude response and uses `stop_reason` to interpret the model turn.  

→ Harness: System 3's `.claude/rules/react.md` and `.claude/skills/deploy-check/SKILL.md` provide deterministic project instructions, scoped rules, and tool restrictions around model work.  

→ Orchestration: System 4's `shift_monitor/pipeline.py`, `warm.py`, and `recovery.py` control data retrieval, state, and cross-shift recovery.

15. **Deterministic vs prompt.**  

→ A deterministic behavior is System 4's SQL-side filtering through `defects_since()`, which applies `ts > ?` and `LIMIT ?` before the model receives the data. Another is System 3's read-only `allowed-tools` list for `deploy-check`. A concrete prompt-based example is the guidance in `CLAUDE.md` to use the project's plan-mode-versus-direct-execution guidance when deciding how to work on the codebase. Deterministic enforcement is appropriate when violating the rule could affect safety, state, or data boundaries, while prompt guidance is useful when the model still needs to apply judgment.

16. **Context, two faces.**  

→ System 2 reduced the raw transcript from 38,708 tokens to an assembled context of 16,859 tokens, a 56.45% reduction. It compressed resolved refund and subscription segments while preserving the active segment. System 4 manages context through persistent state and SQL filtering: the warm tier contains 40 defects, while the `--since 2026-04-01T00:00:00` run processed a filtered slice of 17 defects, and the hot state remained 643 bytes. Both systems bound the context presented to the model, but System 2 does it through position-aware context assembly while System 4 does it through persistent state, SQL-side filtering, and a compact hot state.

17. **Reliability you can't see in one run.**  

→ System 4's recovery tests guarantee the resume/fresh boundary at 30 minutes and verify that stale or empty state starts fresh. A single successful shift run would not demonstrate those failure paths. Testing them before shipping matters because crash recovery only becomes visible when the system actually experiences an interrupted or stale run.

18. **Blast radius.**  

→ In System 4, a misbehaving model could produce an incorrect shift summary, but the data access and state boundaries reduce the blast radius: defects are filtered by the SQL warm tier, hot state is bounded, and recovery logic controls stale state. The recorded-response mode also provides a deterministic way to verify the orchestration without requiring a live model call. The operational enforcement points are the SQL query, state handling, and recovery logic.

---

## Part 3 — Honest assessment

19. **What broke.**  

→ System 1 initially failed because `httpx 0.28.1` was incompatible with the installed `anthropic 0.39.0`, producing `Client.__init__() got an unexpected keyword argument 'proxies'`. I fixed this by installing `httpx<0.28`, resulting in `httpx 0.27.2`, after which the System 1 tests passed with 29 passed. Two earlier live attempts were rejected by the backend, first with a key error and then with a service-budget response. After the environment was available again, the successful run `20260925_112048` processed all 8 fixtures and produced the submitted non-empty trace and `summary.md`.

20. **What you'd change.**  

→ I would improve the evidence workflow by checking every required runtime artifact immediately after each successful run and updating the evidence summaries before packaging. This resubmission demonstrates why that matters: the final package contains the successful System 1 `summary.md` and non-empty trace, the successful System 2 budget/evaluation artifacts, the seeded System 4 filtered run, and the corrected reflection. The final package was then checked for ZIP integrity and required evidence paths before submission.